NGram = list[str]
PiMatrix = dict[str, list[tuple[NGram, float]]]
