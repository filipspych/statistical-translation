SENTENCE_BEGINNING: str = "<beg>"
